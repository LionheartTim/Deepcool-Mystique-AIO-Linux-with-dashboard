#!/bin/bash

# Bepaal automatisch de map waar dit script is opgestart
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Automatische taalherkenning van het Linux-systeem
SYSTEM_LANG=$(echo $LANG | cut -c1-2)

if [ "$SYSTEM_LANG" = "nl" ]; then
    TXT_TITLE="DeepCool Mystique Installer"
    TXT_BODY="Welkom! Dit script gaat het grafische dashboard en de USB-regels definitief installeren op je systeem. Kijk in de terminal (console) om je wachtwoord in te typen als hierom gevraagd wordt."
    TXT_PROGRESS="Installatievoortgang"
    TXT_STEP_MAP="Systeemmappen voorbereiden..."
    TXT_STEP_BIN="Kant-en-klare programma's installeren..."
    TXT_STEP_SYS="USB-rechten configureren (Wachtwoord vereist in terminal)..."
    TXT_STEP_ICON="Applicatie-icoon en snelkoppeling aanmaken..."
    TXT_STEP_DONE="Installatie succesvol voltooid!"
    TXT_DONE_TITLE="Voltooid!"
    TXT_DONE_BODY="Het DeepCool Mystique Dashboard is succesvol geïnstalleerd! Je vindt hem nu tussen je normale applicaties."
else
    TXT_TITLE="DeepCool Mystique Installer"
    TXT_BODY="Welcome! This script will permanently install the graphical dashboard and udev rules on your system. Please check the terminal (console) to type your password if prompted."
    TXT_PROGRESS="Installation Progress"
    TXT_STEP_MAP="Preparing system directories..."
    TXT_STEP_BIN="Installing pre-compiled applications..."
    TXT_STEP_SYS="Configuring USB permissions (Password required in terminal)..."
    TXT_STEP_ICON="Creating system shortcuts and App icon..."
    TXT_STEP_DONE="Installation completed successfully!"
    TXT_DONE_TITLE="Completed!"
    TXT_DONE_BODY="The DeepCool Mystique Dashboard has been successfully installed! You can now find it in your application menu."
fi

# Toon welkomstvenster
zenity --info --title="$TXT_TITLE" --text="$TXT_BODY" --width=400

(
echo "15" ; echo "# $TXT_STEP_MAP" ; sleep 1
mkdir -p ~/.local/bin
mkdir -p ~/.local/share/applications

echo "40" ; echo "# $TXT_STEP_BIN" ; sleep 1
# Kopieer de meegeleverde binaries uit de 'bin' map van de ZIP
cp bin/deepcool-cli ~/.local/bin/deepcool-cli
cp bin/qt-deepcool ~/.local/bin/qt-deepcool

echo "70" ; echo "# $TXT_STEP_SYS" ;
# Schrijf de udev-regels permanent weg naar het systeem
sudo cp 99-deepcool.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules && sudo udevadm trigger

echo "90" ; echo "# $TXT_STEP_ICON" ; sleep 1
# Maak een officieel Linux start-icoon (.desktop bestand) aan voor het applicatiemenu
cat <<EOF > ~/.local/share/applications/deepcool-mystique.desktop
[Desktop Entry]
Type=Application
Name=DeepCool Mystique Dashboard
Comment=Beheer het LCD scherm en de Gyroscope van je waterkoeler
Exec=/home/Tim/.local/bin/qt-deepcool
Icon=hwinfo
Terminal=false
Categories=System;Settings;
EOF

# Maak het snelkoppeling-bestand uitvoerbaar
chmod +x ~/.local/share/applications/deepcool-mystique.desktop

echo "100" ; echo "# $TXT_STEP_DONE" ; sleep 1
) | zenity --progress --title="$TXT_PROGRESS" --percentage=0 --auto-close

# Toon succesmelding
zenity --info --title="$TXT_DONE_TITLE" --text="$TXT_DONE_BODY" --width=400
